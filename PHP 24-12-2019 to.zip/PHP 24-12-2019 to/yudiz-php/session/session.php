<!DOCTYPE html>
<html>
<head>
	<title>Session</title>
</head>
<body>
	<h1>Php Session</h1>
	Count User Views in the page::<br>
	<?php
		session_start();
		if(isset($_SESSION['views']))
			$_SESSION['views']=$_SESSION['views']+1;
		else
			$_SESSION['views']=1;
		echo "<br><br>you visited this page is =".$_SESSION['views']." times.<br>";
		$_SESSION["favcolor"] = "green";
		$_SESSION["favanimal"] = "cat";
		echo "<br><br><br><br>Session variables are set:";
		print_r($_SESSION);
	?>
	<?php
	echo "<br>";
$name="Cat";
${$name}="Dog";
${${$name}}="Monkey";
echo $name. "<br>";
echo ${$name}. "<br>";
echo $Cat. "<br>";
echo ${${$name}}. "<br>";
echo $Dog. "<br>";
	?>
</body>
</html>