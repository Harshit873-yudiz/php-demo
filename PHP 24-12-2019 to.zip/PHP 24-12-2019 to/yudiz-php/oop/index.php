<!DOCTYPE html>
<html>
<head>
	<title>oop concepts</title>
</head>
<body>
	<h1>oops concept</h1>
	<!--?php
		class Fruit{
			//prooperties
			public $name;
			public $color;

			//method
			function set_name($name){
				$this->name=$name; 
			}
			function get_name(){
				return $this->name;
			}
			function set_color($color){
				$this->color=$color;
			}
			function get_color(){
				return $this->color;
			} 
		}
		$apple = new Fruit();
		$apple->set_name('Apple');
		$apple->set_color('Red');
		echo "Name: " . $apple->get_name();
		echo "<br>";
		echo "Color: " .  $apple->get_color();
	?-->

	<!-- Constructor -->
	<!--?php

		class user{
			public $uname;
			public $lname;
			function __construct($uname,$lname){
				$this->uname=$uname;
				$this->lname=$lname;
			}
			function get_uname(){
				return $this->uname;
			}
			function get_lname(){
				return $this->lname;
			}
		}	
		$fname=new user("Harshit","Shah");
		echo "<br><br>Constructor:<br><br>";
		echo $fname->get_uname();
		echo "<br>";
		echo $fname->get_lname();
	?-->

	<!-- Destructor -->
	<!--?php
		class apple{
			public $name;
			public $color;
			function __construct($name,$color){
				$this->name=$name;
				$this->color=$color;
			}
			function __destruct(){
				echo "<br><br>Destructor:<br>";
				echo "<br>Fruit name is: {$this->name} and the Color is: {$this->color}";
			}
		}
		$Name=new apple("Apple","red");
	?-->

	<!-- inheritance -->
	<!--?php  
		class animal{
			public $animname;

			function __construct($animname){
				$this->animname=$animname;
			}
			protected function intro(){
				echo  "name is: {$this->animname}";
			}
		}
		class dog extends animal{
			function info(){
				echo "This is a Dog   ";
				$this->intro();
			}
		}
		$anim=new dog("mark");
		$anim->info();
	?-->
	<?php  
			class a{
				public $name;
				
				function __construct($name){
					$this->name=$name;
				}
				function intro(){
					echo "Class A:   {$this->name}";
				}
			}

			trait b{
				function dogtype(){
					echo "class B:   ";
				}
			}

			class c extends a{
				use b;
				function doginfo(){
					echo "Class C:   ";
				}
			}

			$anim= new c("Hello Wolrd");
			$anim->doginfo();
			$anim->dogtype();
			$anim->intro();
	?>
	<!--constant-->
	<?php
		class animal{
			const message="<br><br>Dog is a Friendly animal";
			public function dog(){
				echo self::message;
			}
		}
		$msg=new animal();
		$msg->dog();
	?>
	<!--Abstract class-->
	<?php
		//parent class
		abstract class Car{
			public $name;
			public function __construct($name){
				$this->name=$name;
			}
			abstract public function intro():string;
		}
		//child class
		class Audi extends Car{
			public function intro():string{
				return "<br><br>Choose German Quality! I am an $this->name!";
			}
		}
		//create object from the child classes
		$audi= new audi("Audi");
		echo $audi->intro();
	?>

	<?php  
		abstract class ParentClass{
			abstract protected function prefixName($name);
		}
		class ChildClass extends ParentClass{
			public function prefixName($name){
				if($name=="John Doe"){
					$prefix="Mr.";
				}
				elseif($name=="Jane Doe"){
					$prefix="Mrs.";
				}
				else{
					$prefix="";
				}
				return "{$prefix}{$name}";
			}
		}
		$class = new ChildClass;
		echo "<br><br>";
		echo $class->prefixName("John Doe");
		echo "<br>";
		echo $class->prefixName("Jane Doe");
	?>
	<!--trait-->
	<?php  
		trait message1{
			public function msg1(){
				echo "Hello  ";
			}
		}
		trait message2{
			public function msg2(){
				echo "World!";
			}
		}
		class Welcome{
			use message1,message2;
		}
		$obj= new Welcome();
		echo "<br><br>";
		$obj->msg1();
		$obj->msg2();
	?>

	<!-- static method -->

	<?php  
		class greeting{
			public static function hello(){
				echo "<br><br>Hello Wolrd";
			}
		}

		greeting::hello();
	?>
</body>
</html>