<?php
	echo "<a href='#'>Home</a>  
		  <a href='#'>Contact-Us</a>
		  <a href='#'>About-Us</a>";
?>