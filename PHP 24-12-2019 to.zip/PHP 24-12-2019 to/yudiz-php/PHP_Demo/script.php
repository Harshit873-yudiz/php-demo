<?php  
	echo "<h1>Hello</h1>";

	/*  h: 12 hour format
		H:24 hour format
		i:minutes
		s:second
		u:microseconds
		a:lowecase am or pm
		I:full text for the day
		F:full text month
		j:day of month
		S:suffix
		Y:year in 4 digits
	*/
	//date print
	echo date("h:i:a,F I");

	$studentName=$_POST['studentName'];
	$grade=$_POST['grade'];
	$div=$_POST['div'];

	echo "<h1>Student Information</h1>";
	echo "Student Name is" . $studentName;
	echo "Student grade is" . $grade;
	echo "Student Division is" . $div;
	echo "<br>";
	
	$x=10;
	$y=10.5;
	$z=array("abc","xyz","pqr");
	var_dump($x,$y,$z);
	echo "<br>";

	class car{
		function car(){
			$this->model="i10";
		}
	}
	//create an object
	$x= new car();
	//show object property
	echo $x->model;
	echo "<br><br><br>";

	echo strlen("Harshit");
	echo "<br>";
	echo str_word_count("Harshit Shah");
	echo "<br>";
	echo strrev("Harshit");
	echo "<br>";
	echo strpos("Harshit","s");
	echo "<br>";
	echo str_replace("world","Harshit","Hello world!");
	echo "<br>";
	define("hello", "Hello Harshit");
	echo hello;
	echo "<br>";
	define("WORLD", "Hello Harshit",true);
	echo world;
	echo "<br>";
	$a=5;
	$b=10;
	echo $a+=$a;
	echo "<br>";
	$i=1;
	$k=1;
	for($i=0;$i<5;$i++){
		echo $i++;
		echo "==" . ++$k."<br>";
	}


	$car=array(
		array("volvo",10,2),
		array("BMW",5,4)
	);
	echo "car name is: ".$car[0][0]."  In stock  ".$car[0][1]."  sale  ".$car[0][2]."<br>";
	echo "car name is: ".$car[1][0]."  In stock  ".$car[1][1]."  sale  ".$car[1][2];
	echo "<br><br>";
	for($row=0;$row<2;$row++){
		echo "row num is".$row;
		echo "<ul>";
		for($col=0;$col<3;$col++){
			echo "<li>".$car[$row][$col]."</li>";
		}
		echo "</ul>";
	}

	echo $_SERVER['PHP_SELF'];
	echo "<br>";
	echo $_SERVER['SERVER_NAME'];
	echo "<br>";
	echo $_SERVER['HTTP_HOST'];
	echo "<br>";
	echo $_SERVER['HTTP_REFERER'];
	echo "<br>";
	echo $_SERVER['HTTP_USER_AGENT'];
	echo "<br>";
	echo $_SERVER['SCRIPT_NAME'];
?>