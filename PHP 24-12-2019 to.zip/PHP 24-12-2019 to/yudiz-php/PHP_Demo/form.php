<!DOCTYPE html>
<html>
<head>
	<title>Form validation</title>
	<style type="text/css">
		.error{
			color: red;
		}
	</style>
</head>
<body>
	<div class="menu">
		<?php
		include 'header.php';
		?>
	</div>
	<?php
		$nameErr= $emailErr="";
		$name= $email="";

		//name
		if($_SERVER['REQUEST_METHOD']=='POST'){
			if(empty($_POST['name'])){
				$nameErr="name is required" ;
			}
			else{
				$name=$_POST['name'];
				if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      				$nameErr = "Only letters and white space allowed";
				}
			}
		}

		//email
		if($_SERVER['REQUEST_METHOD']=='POST'){
			if(empty($_POST['email'])){
				$emailErr="email is required" ;
			}
			else{
				$email=$_POST['email'];
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
 					 $emailErr = "Invalid email format";
				}
			}
		}
			
	?>
	<h1>User Form</h1>
	<form method="POST" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]);?>">	
		<label for="name">Name
			<input type="name" name="name"/>
			<span class="error">* <?php echo $nameErr;?></span>
		</label><br>

		<label for="email">email
			<input type="email" name="email"/>
			<span class="error">* <?php echo $emailErr;?></span>
		</label><br>

		<input type="submit" name="submit" value="submit">
	</form>	
	<?php
		echo "name is".$name."<br>";
		echo "email is".$email."<br>";
	?>
	<br>
	<?php
		//read file
		echo "Text File Read:<br>";
		$myfile=fopen("files/demo.txt","r") or die("unable to open a file");
		echo fread($myfile,filesize("files/demo.txt"));
		fclose($myfile);

		//read 1 line form the file
		echo "<br><br>";
		echo "Read only 1 line form the file:<br>";
		$myfile=fopen("files/demo.txt","r") or die("unable to open a file");
		echo fgets($myfile);
		fclose($myfile);

		//end of file
		echo "<br><br>";
		echo "Use end of file feof:<br>";
		$myfile=fopen("files/demo.txt","r") or die("un able to open a file");
		// output 1 line to end of line
		while (!feof($myfile)) {
			echo fgets($myfile)."<br>";
		}
		fclose($myfile);

		//display single char of a file
		echo "<br><br>";
		echo "Use fgetc to find single character:<br>";
		$myfile=fopen("files/demo.txt","r") or die("un able to open a file");
		// output 1 line to end of line
		while (!feof($myfile)) {
			echo fgetc($myfile)."<br>";
		}
		fclose($myfile);

		//file write
		$myfile=fopen("files/hello.txt","w");
		$txt="Hello Wolrd";
		fwrite($myfile,$txt);
		fclose($myfile);
	?>
</body>
</html>