<!DOCTYPE html>
<html>
<head>
	<title>Cookie</title>
</head>
<?php
	//create and retrive cookie
	$cookie_name="user";
	$cookie_value="Harshit Shah";
	setcookie($cookie_name,$cookie_value,time()+(60),"/");
	//delete cookie
	//setcookie("user","",time()-60,"/");
?>
<body>
	<?php
		//create and retrive cookie
		if(!isset($_COOKIE[$cookie_name])){
			echo "Cookie Name Is: ".$cookie_name."is not set!"; 
		}
		else{
			echo "Cookie Name Is: ".$cookie_name."is set!<br>";
			echo "Value Is: ".$_COOKIE[$cookie_name];
		}
	?>
	<!--?php	
		echo "<br>cookie user deleted";
	?-->
</body>
</html>