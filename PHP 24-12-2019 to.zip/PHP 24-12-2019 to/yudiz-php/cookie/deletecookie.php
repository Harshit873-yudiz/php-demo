<!DOCTYPE html>
<html>
<head>
	<title>Cookie</title>
</head>
<?php
	//delete cookie
	setcookie("user","",time()-60,"/");
?>
<body>
	
	<?php	
		echo "<br>cookie user deleted";
	?>
</body>
</html>