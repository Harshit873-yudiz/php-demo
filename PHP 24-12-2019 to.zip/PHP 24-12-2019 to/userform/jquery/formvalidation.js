$("document").ready(function() {
  $("form[name='registration']").validate({
    rules: {
      name:{
        required:true,
        minlength:3,
        maxlength:12,
        regex:"[^0-9]$"
      },
      email: {
        required: true,
        maxlength:150,
        email: true
      },
      password: {
        required: true,
        minlength: 5,
      },
      confirmpassword:{
        required:true,
        equalTo:'#password'
      },
      contact:{
        required:true,
        minlength:9
      },
      url:{
        required:true,
      },
      file:{
        required: true,
        accept: "image/jpg,image/jpeg,image/png,image/gif"
      }
    },
    messages: {
      name:{
        required:"Enter name",
        minlength:"minlength3",
        maxlength:"maxlength12",
        regex:"do not insert number"
      },
      email:{
        required:"Enter Email id",
        email: "Please enter a valid email address",
        maxlength:"only 150 char"
      },
      password: {
        required: "Please Enter password",
        minlength: "minlength 5",
      },
      confirmpassword:{
        required:"Please Enter password",
        equalTo:"Enter password as above"
      },
      contact:{
        required:"please enter Contact number",
        minlength:"length should be >9"
      },
      url:{
        required:"Enter Web Site"
      },
      file:{
        required: 'Select Image',
        accept: 'Not an image!'
      }
    },
    errorElement : 'div',
      submitHandler: function(form) {
        $("form").reset();
        form.submit();
      },
       highlight: function (element, errorClass) {
        $(element).closest('.form-group').addClass('has-error');
      },
      unhighlight: function (element, errorClass) {
        $(element).closest('.form-group').removeClass('has-error');
      },
      errorPlacement: function(error, element) {
        //error.insertAfter(element);
        error.appendTo(element.parent());       
      }

  });
  
});

// $("#viewdata").click(function(){
//     $()       
// });

$.validator.addMethod(
      "regex",
      function(value, element, regexp) {
          var check = false;
          var re = new RegExp(regexp);
          return this.optional(element) || re.test(value);
      }
);