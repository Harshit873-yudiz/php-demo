<!DOCTYPE html>
<html>
<head>
	<title>View Data</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script type="text/javascript" src="../jquery/jquery-3.4.1.slim.min.js"></script>
	<script type="text/javascript" src="../jquery/popper.min.js"></script>
	<script type="text/javascript" src="../jquery/bootstrap.min.js"></script>

	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery.validate.min.js"></script>
	<script type="text/javascript" src="../jquery/additional-methods.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery-ui.js"></script>
</head>
<body>
	<div class="container">
		<br><a class="btn btn-primary" href="../index.html">Add Data</a>
		<a class="btn btn-primary" href="viewdata.php">View Data</a>
		<a class="btn btn-primary" href="trash.php">Trash Data</a>
		<br><br>
	</div>	
	<?php
		$conn=new mysqli("localhost","root","","myDb");

			//check connection
			if($conn->connect_error){
				die("connection failed:".$conn->connect_error);
			}
		echo "<div class='container'><style>
			table, th, td {
	    	border: 1px solid black;
			}
			</style>";	
		$sql="SELECT * From userinfo WHERE userid=".$_GET['id']."";
		$view=$conn->query($sql);

		if ($view->num_rows > 0) {
	    	echo "<table><tr><th>Field</th><th>Field Value</th></tr>";
	    	while($row = $view->fetch_assoc()) {
	        	echo "<tr><td>".$row["field"]."</td><td>".$row["fieldvalue"]
	        	."</td></tr>";
	    	}
	    		echo "</table>";
			} 
			else {
	    		echo "0 results";
		} 	

	?>
</body>
</html>