<!DOCTYPE html>
<html>
<head>
	<title>View Data</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script type="text/javascript" src="../jquery/jquery-3.4.1.slim.min.js"></script>
	<script type="text/javascript" src="../jquery/popper.min.js"></script>
	<script type="text/javascript" src="../jquery/bootstrap.min.js"></script>

	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery.validate.min.js"></script>
	<script type="text/javascript" src="../jquery/additional-methods.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery-ui.js"></script>
</head>
<body>
	<div class="container">
		<br><a class="btn btn-primary" href="../index.html">Add Data</a>
		<a class="btn btn-primary" href="trash.php">Trash Data</a>	
	<h1>View Data</h1>
<?php
	if (isset($_GET['id'])) {
		$conn=new mysqli("localhost","root","","myDb");

		//check connection
		if($conn->connect_error){
			die("connection failed:".$conn->connect_error);
		}
		else{
			echo "<div class='container'><style>
			table, th, td {
	    	border: 1px solid black;
			}
			</style>";
	
		}
		//remove
		
		$sql="UPDATE user SET status=0 WHERE id=".$_GET['id']."";
		$conn->query($sql);

		$conn->close();	
	}
	$conn=new mysqli("localhost","root","","myDb");

		//check connection
		if($conn->connect_error){
			die("connection failed:".$conn->connect_error);
		}
		else{
			echo "<div class='container'><style>
			table, th, td {
	    	border: 1px solid black;
			}
			</style>";
		    
		}
		
	?> 
	<form name="bulk_action_form" action="trash.php" method="post" onSubmit="
		return delete_confirm();">
	    <table class="bordered">
	        <thead>
	        <tr>
	            <th><input type="checkbox" id="select_all" value=""/></th>        
	            <th>Name</th>
	            <th>Email</th>
	            <th>Action</th>
	        </tr>
	        </thead>
	    	<?php    
			    $sql1="SELECT id,name,email From user where status=0";
			    $view=$conn->query($sql1);
			    // List all records
			    if($view->num_rows > 0){
			        while($row = $view->fetch_assoc()){
		    ?>
		    <tr>
	            <td align="center"><input type="checkbox" name="checked_id[]" 		class="checkbox" value="<?php echo $row['id']; ?>"/>
	            </td>   
	            
	            <td><?php echo $row['name']; ?></td>
	            <td><?php echo $row['email']; ?></td>
	            <td><?php echo"<button class='showvalue' onclick=\"window.location.href='updatedata.php?id=".$row["id"]."';\">Edit</button>  <button class='showvalue' onclick=\"window.location.href='trash.php?id=".$row["id"]."';\">Trash</button>
		        	"?>
	            </td>
	        </tr>
	         <?php } }else{ ?>
	            <tr><td colspan="5">No records found.</td></tr>
	        <?php } ?>
	    </table><br>
	    <input type="submit" class="btn btn-primary" value="Trash"/>
	</form>
	
	<script type="text/javascript">
		
		function delete_confirm(){
		    if($('.checkbox:checked').length > 0){
		        $('.checkbox:checked').each(function(){
		                //console.log(this.value);
		                $.ajax({
							url:"del.php",
							type:"POST",
							data:"id="+this.value,
							success:function(data){
								console.log(data);	
								location.reload(true);
							}
						});
		            });
		        return false;
		    }
		    else{
		        //alert('Select at least 1 record to trash.');
		        return false;
		    }
		}

		//jquery 

		$(document).ready(function(){
		    $('#select_all').on('click',function(){
		        if(this.checked){
		            $('.checkbox').each(function(){
		                this.checked = true;
		            });
		        }
		        else{
		             $('.checkbox').each(function(){
		                this.checked = false;
		            });
		        }
		    });

		    $('.checkbox').on('click',function(){
		        if($('.checkbox:checked').length == $('.checkbox').length){
		            $('#select_all').prop('checked',true);
		        }
		        else{
		            $('#select_all').prop('checked',false);
		        }
		    });
		});
	</script>
</div>		
</body>
</html>