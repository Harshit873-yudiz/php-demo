<!DOCTYPE html>
<html>
<head>
	<title>update data</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script type="text/javascript" src="../jquery/jquery.js"></script>
	<script type="text/javascript" src="../jquery/jquery-3.4.1.slim.min.js"></script>
	<script type="text/javascript" src="../jquery/popper.min.js"></script>
	<script type="text/javascript" src="../jquery/bootstrap.min.js"></script>

	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery.validate.min.js"></script>
	<script type="text/javascript" src="../jquery/additional-methods.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery-ui.js"></script>
	<script type="text/javascript" src="../jquery/formvalidation.js"></script>
</head>
<body>

</body>
</html>
	<?php

		//name email update
		if (isset($_POST['email'])) {	
			$conn=new mysqli("localhost","root","","myDb");
			//check connection
			if($conn->connect_error){
				die("connection failed:".$conn->connect_error);
			}
			//update user
			$email1 = $_POST['email'];
			$name1 = $_POST['name'];
			$sql="UPDATE user SET name='$name1' , email='$email1' where id=".$_GET['id']."";
			if($conn->query($sql)){
				//success 
			}
			else{
				echo"fail";
			}
		}
		//update gender
		if(isset($_POST['gender'])){
			//update gender userinfo
			$gender = $_POST['gender'];
			$sql2="UPDATE userinfo SET field='gender',fieldvalue='$gender' WHERE field='gender' AND userid=".$_GET['id']."";
		    $conn->query($sql2);
		}
		//contact update
		if(isset($_POST['contact'])){
			$contact=$_POST['contact'];
			$sql2="UPDATE userinfo SET field='contact',fieldvalue='$contact' WHERE field='contact' AND userid=".$_GET['id']."";
		    $conn->query($sql2);
		}
		//File Upload
		if(isset($_FILES["fileToUpload"])){
        	$target_dir="upload/";
			$target_file=$target_dir.basename($_FILES["fileToUpload"]["name"]);
			$uploadOk =1;
			$imageFileType=strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

			// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) {
			    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			    if($check !== false) {
			        echo "File is an image - " . $check["mime"] . ".";
			        $uploadOk = 1;
			    } else {
			        echo "File is not an image.";
			        $uploadOk = 0;
			    }
			}
			
			//check if file is already exist or not?
			if(file_exists($target_file)){
				echo "file already exist";
				$uploadOk =0;
			}

			// Check file size
			if ($_FILES["fileToUpload"]["size"] <0) {
			    echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}

			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
			} 
			else {
			    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			        // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
			    	// echo "<img src='".$target_file."' height=100 width=50 />";
			        $filename= $_FILES["fileToUpload"]["name"];
			        
			        $sql2="UPDATE userinfo SET field='image',fieldvalue='$filename' WHERE field='image' AND userid=".$_GET['id']."";
	        		$conn->query($sql2);
	   		    } else {
			        echo "Sorry, there was an error uploading your file.";
			    }
			}
		//file upload end
			
			$conn->close();
		}
		//defult values
		$name="";
		$email="";
		$target_file1="";
		$gender="";
		$contact="";
		##connection check
		$conn=new mysqli("localhost","root","","myDb");
		if($conn->connect_error){
			die("connection failed:".$conn->connect_error);
		}
		if (isset($_GET['id'])) {
			
			## get user name and email 
			$sql1="SELECT * FROM user WHERE id=".$_GET['id']."";

			if($view=$conn->query($sql1)){
				$row = $view->fetch_assoc();

				$name= $row['name'];
				$email=$row['email'];
				
				$checkValidate = 1;
			}
			else{
				die("Data Not Found Error : ".$conn->error);
			}
			##	get userinfo file	
			$id = $_GET['id'];
			$sql1="SELECT * FROM userinfo WHERE userid=$id";

			if($view=$conn->query($sql1)){
				while($row = $view->fetch_assoc()){
					if($row['field']=='image'){
						$target_file1= "upload/". $row['fieldvalue'];	
					}
					if($row['field']=='gender'){
						$gender=$row['fieldvalue'];
					}
					if($row['field']=='contact'){
						$contact=$row['fieldvalue'];
					}

				}
			}
			else{
				die("Data Not Found Error : ".$conn->error);
			}
			$conn->close();
		}
					
	?>
	<div class="container" style="border:solid;margin-top: 30px;">
		
		<br><a class="btn btn-primary" href="viewdata.php">View Data</a>
		<a class="btn btn-primary" href="../index.html">Add Data</a>
		<form method="POST" name="registration" style="color: red;padding: 30px;"
		enctype="multipart/form-data">

			<h2 style="color: blue"><u>Php Update Form</u></h2>
			<div class="form-group">
				<label for="name" style="color: blue"> Name</label>	
				 <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name"  value="<?php echo $name;?>" />		  
			</div>
			<div class="form-group">
			    <label for="email" style="color: blue">Email</label>
			    <input type="email" class="form-control" id="email" placeholder="Enter Email Address" name="email" value="<?php echo $email;?>"/>
			</div>
			<div class="form-group">
				<label for="fileToUpload" style="color: blue">Upload Image</label>
				<input type="file" class="form-control" name="fileToUpload" id="fileToUpload" value="<?php echo $target_file;?>" />
				<?php echo "<img src='".$target_file1."' height=150 width=100 />";?>
			</div>
			<div class="radio" style="color: blue">Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  	<label style="color: blue">Male
			    	<input type="radio" name="gender" id="male" value="Male"<?php if ($gender == "Male") echo "checked"; ?>/>
			  	</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  	<label style="color: blue">Female 
			    	<input type="radio" name="gender" id="female"value="Female"<?php if ($gender == "Female") echo "checked"; ?>/>
			  	</label>
			</div> 
			<div class="form-group">    
			    <label for="contact" style="color: blue">Contact</label>
			    <input type="tel" class="form-control" id="contact" name="contact" placeholder="Enter Contact number" value="<?php echo $contact;?>"/>
			</div>
		    <button type="submit" class="btn btn-primary" 
		    value="<?php echo $file;?>">update</button>	
		</form>
	</div>
</body>
</html>