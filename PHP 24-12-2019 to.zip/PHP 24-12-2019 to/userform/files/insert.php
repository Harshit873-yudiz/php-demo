<!DOCTYPE html>
<html>
<head>
	<title>View Data</title>
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<script type="text/javascript" src="../jquery/jquery-3.4.1.slim.min.js"></script>
	<script type="text/javascript" src="../jquery/popper.min.js"></script>
	<script type="text/javascript" src="../jquery/bootstrap.min.js"></script>

	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery.validate.min.js"></script>
	<script type="text/javascript" src="../jquery/additional-methods.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery-ui.js"></script>
</head>
<body>
	<div class="container">
		<br><a class="btn btn-primary" href="../index.html">Add Data</a>
		&nbsp;&nbsp;&nbsp;
		<a class="btn btn-primary" href="viewdata.php">View Data</a><br><br>
	</div>
	<?php
	// print_r($_POST);
	// print_r($_FILES);
	$fileToUpload="";
		$conn=new mysqli("localhost","root","","myDb");

			//check connection
			if($conn->connect_error){
				die("connection failed:".$conn->connect_error);
			}
			else{
				echo "<div class='container'>Connect successfully";
			}
			
			//escape user input for security
			$name=$conn->real_escape_string($_REQUEST['name']);
			$email=$conn->real_escape_string($_REQUEST['email']);
			
			//password
			$password=$conn->real_escape_string($_REQUEST['password']);
			$pass=md5($password);
			
			$gender=$conn->real_escape_string($_REQUEST['gender']);
			
			$sql1="INSERT INTO user(name,email,password)
			VALUES('$name','$email','$pass')";
			$conn->query($sql1);
		 	
			$lastid = mysqli_insert_id($conn); 

		 	foreach ($_POST as $key=>$value) {	
		 		if ($key=='name'||$key=='email'||$key=='password'||$key=='confirmpassword') {
		 			continue;
		 		}
		 		if (is_array($_POST[$key])==true) {
		        	//$value=implode($value," : ");
		        	$value=serialize($value);
		        }

				$sql2="INSERT INTO userinfo(userid,field,fieldvalue)
		        VALUES($lastid,'$key','$value')";

		        $conn->query($sql2);	
			}
			if(isset($_FILES["fileToUpload"])){
		        	
	        	$target_dir="upload/";
				$target_file=$target_dir.basename($_FILES["fileToUpload"]["name"]);
				$uploadOk =1;
				$imageFileType=strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

				// Check if image file is a actual image or fake image
				if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				}
				
				//check if file is already exist or not?
				if(file_exists($target_file)){
					echo "file already exist";
					$uploadOk =0;
				}

				// Check file size
				if ($_FILES["fileToUpload"]["size"] <0) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}

				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
					&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}

				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} 
				else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				        
				        $filename= $_FILES["fileToUpload"]["name"];
				        $sql2="INSERT INTO userinfo(userid,field,fieldvalue)
				        VALUES($lastid,'image','$filename')";

				        $conn->query($sql2);	
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}

			}	
			echo '<br>Record inserted</div>';
			$conn->close();
	?>
</body>
</html>	