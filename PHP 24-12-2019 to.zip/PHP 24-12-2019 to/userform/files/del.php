<?php  
	if (isset($_POST['id'])) {
		$conn=new mysqli("localhost","root","","myDb");
		//check connection
		if($conn->connect_error){
			die("connection failed:".$conn->connect_error);
		}

		$id=$_POST['id'];
		echo $id;
		$sql="UPDATE user SET status=1 WHERE id=".$_POST['id']."";
		$conn->query($sql);
		$conn->close();
	}
?>